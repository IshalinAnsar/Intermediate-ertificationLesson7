package home1.ui.commands;

public interface Option {
    String description();

    void execute();
}
