package home1.model;

import java.io.Serializable;

public interface LoadFrom {
    Serializable load(String path);
}
