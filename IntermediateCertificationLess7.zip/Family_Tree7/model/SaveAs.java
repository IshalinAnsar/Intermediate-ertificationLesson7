package home1.model;

import java.io.Serializable;

public interface SaveAs {
    void save(String path, Serializable obj);
}
